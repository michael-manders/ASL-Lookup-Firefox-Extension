console.log("ASL Lookup extension running");
